Thanks for purchasing my soviet interior props set! It took me over 500 hours to model, texture and optimize all of these.

All these models use the same three textures (4k atlas) and only two materials 
(the basic material is one-sided, and assets called "Bath_add", "Curtains", "Towel_b" use two-sided material. Plants also use two-sided one for leaves).

Packed RMA: R - Roughness, G - Metallic, B - AO

Tris count of all models is ~52k so they can be used on high-end mobile devices (probably)
